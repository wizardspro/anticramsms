<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class manage_client extends CI_Controller {

	function __construct() {
		parent::__construct();
	}

	
	/********************* client view ************************/

	function send_request() {

		/*if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			

		}
		else {
		    header( 'Location: ../dashboard	' );
		}
		/**/
		if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
			$this->form_validation->set_rules('no_of_manpower', 'No. of Manpower', 'required|xss_clean');
			$this->form_validation->set_rules('date_range_picker', 'Date Request', 'required|xss_clean');
			/*$this->form_validation->set_rules('emp_type', 'Employee Type', 'required|xss_clean');*/
			$this->form_validation->set_rules('emp_department', 'Employee Department', 'required|xss_clean');
			$this->form_validation->set_rules('emp_gender', 'Gender', 'required|xss_clean');
			$this->form_validation->set_rules('remarks', 'Remarks', 'required|xss_clean');
			$this->form_validation->set_rules('documents_req', 'Documents', 'xss_clean');

			$query =$this->db->query("select count(*) as count from request where year(date_requested) = year(now()) group by year(date_requested)");
				if ($query->num_rows() > 0)
				{
				   foreach ($query->result() as $row)
				   { 
				      $p= $row->count + 1;
				   }
					$p = sprintf("%04d",$p) ;
					$date = date('Y'); //this returns the current date
					$req_id = 'AMI-REQ-' . substr($date, -2).$p;
				}
				else
				{ 
					$p = '0001';
					$p = sprintf("%04d",$p) ;
					$date = date('Y'); //this returns the current date
					$req_id = 'AMI-REQ-' . substr($date, -2).$p;

				}

			
			if ($this->form_validation->run() == true)
			{

				
				//echo date("Y-m-d", strtotime($arr[0]));
	  			$a =  $this->input->post("date_range_picker");
	  			$arr = explode("-",$a);
	  			/*if($arr){
	  				echo date("Y-m-d", strtotime($arr[1]))."<br>";

	  			} 
	  			else{
	  				echo "NO<br>";
	  			}*/
				$data = array(
					'request_id' => $req_id,
					'client_id' => $this->session->userdata('user_id'),
					'no_of_manpower' => $this->input->post("no_of_manpower"),
					'date_requested' => date("Y-m-d", strtotime($arr[0])),
					'is_to' => date("Y-m-d", strtotime($arr[1])),
					'remarks' => $this->input->post("remarks"),
					'emp_reqdocuments' => $this->input->post("documents_req"),
					'emp_type' => $this->input->post("emp_type"),
					'emp_department' =>$this->input->post("emp_department"),
					'emp_gender' =>$this->input->post("emp_gender"),
					'company' => $this->session->userdata("company")
				);

				$this->load->model('request_model');
				$this->request_model->send_request($data);
		  
				$success_string = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Your Manpower Request has been sent. Just wait for confirmation.</div>';
				$this->session->set_flashdata('request_sent',$success_string); 

				//echo "ECHO";
				redirect(base_url().'client/dashboard', 'refresh');	
			}
		else
		{
			echo validation_errors();

		}

		}
		else {
		    header( 'Location: ../dashboard	' );
		}
		
			
	}

	function hide_confirmed() {
	/*	if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
					}
		else {
		    header( 'Location: ../dashboard	' );
		}*/
		$this->load->model('request_model');
		$this->request_model->hide_confirmed($this->input->post("id"), array("is_read" => "1"));
		
	}
		

}

/* End of file client.php */
/* Location: ./application/controllers/client.php */